<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include '../database.php';
include '../queries.php';
$database = new Database();
$db = $database->getConnection();
$item = new Library($db);
$item->staff_ID = isset($_GET['staff_ID']) ? $_GET['staff_ID'] : die();
$item->searchUser();
if($item->stffname != null){

// create array
$array = array(
"staff_ID" => $item->staff_ID,
"stffname" => $item->stffname,
"stflname" => $item->stflname,
"stfcontactnumber" => $item->stfcontactnumber,
"stfaddress" => $item->stfaddress,
"stfemail" => $item->stfemail,
"stfpassword" => $item->stfpassword,
"stftype" => $item->stftype

);

http_response_code(200);
echo json_encode($array);
}
else{
http_response_code(404);
echo json_encode("User not found.");
}
?>