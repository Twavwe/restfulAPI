<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once '../database.php';
include_once '../queries.php';
$database = new Database();
$db = $database->getConnection();
$item = new Library($db);


$item->bookID = $_GET['book_ID'];
$item->title = $_GET['bktitle'];
$item->studid = $_GET['stud_id'];
$item->studname = $_GET['studname'];
$item->staff_id = $_GET['staff_id'];
$item->staffname = $_GET['staffname'];
$item->studentNOcopies = $_GET['studentNOcopies'];
$item->releaseDate = $_GET['releaseDate'];
$item->dueDate = $_GET['dueDate'];

if($item->createBorrower()){
echo 'Created successfully.';
} else{
echo 'could not be created.';
}
?>