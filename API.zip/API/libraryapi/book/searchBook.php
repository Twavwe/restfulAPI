<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include '../database.php';
include '../queries.php';
$database = new Database();
$db = $database->getConnection();
$item = new Library($db);
$item->book_ID = isset($_GET['book_ID']) ? $_GET['book_ID'] : die();
$item->searchBook();
if($item->bktitle != null){

// create array
$array = array(
"book_ID" => $item->book_ID,
"bktitle" => $item->bktitle,
"bkedition" => $item->bkedition,
"bkauthor" => $item->bkauthor,
"bkpublisher" => $item->bkpublisher,
"bkcopies" => $item->bkcopies,
"bksource" => $item->bksource,
"bkcost" => $item->bkcost,
"bkremarks" => $item->bkremarks
);

http_response_code(200);
echo json_encode($array);
}
else{
http_response_code(404);
echo json_encode("Book not found.");
}
?>