<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once '../database.php';
include_once '../queries.php';
$database = new Database();

$db = $database->getConnection();
$items = new Library($db);
$records = $items->getBooks();
$itemCount = $records->num_rows;
echo json_encode($itemCount);
if($itemCount > 0){
$bookArray = array();
$bookArray["body"] = array();
$bookArray["itemCount"] = $itemCount;
while ($row = $records->fetch_assoc())
{
array_push($bookArray["body"], $row);
}
echo json_encode($bookArray);
}
else{
http_response_code(404);
echo json_encode(
array("message" => "No record found.")
);
}
?>