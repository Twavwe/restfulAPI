<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../database.php';
include_once '../queries.php';

$database = new Database();
$db = $database->getConnection();
$item = new Library($db);

$item->book_ID = isset($_GET['book_ID']) ? $_GET['book_ID'] : die();

$item->bktitle = $_GET['bktitle'];
$item->bkedition = $_GET['bkedition'];
$item->bkauthor = $_GET['bkauthor'];
$item->bkpublisher = $_GET['bkpublisher'];
$item->bkcopies = $_GET['bkcopies'];
$item->bksource = $_GET['bksource'];
$item->bkcost = $_GET['bkcost'];
$item->bkremarks = $_GET['bkremarks'];

if($item->updateBook()){
echo json_encode("Book data updated.");
} else{
echo json_encode("Data could not be updated");
}
?>