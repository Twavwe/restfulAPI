<?php
class Library{
    // database connnection
    private $db;
    // table of customer
    private $tableStudent = "tblstudent";
    public $stud_id;
    public $stfname;
    public $stlname;
    public $stcourse;
    public $styear;
    public $stcontact;
    public $stage;
    public $stbirthdate;
    public $stgender;

    //  table of book
    private $tableBook = "tblbook";
    public $book_ID;
    public $bktitle;
    public $bkedition;
    public $bkauthor;
    public $bkpublisher;
    public $bkcopies;
    public $bksource;
    public $bkcost;
    public $bkremarks;

    //  table users
    private $tableUser = "tblusers";
    public $staff_ID;
    public $stffname;
    public $stflname;
    public $stfcontactnumber;
    public $stfaddress;
    public $stfemail;
    public $stfpassword;
    public $stftype;

    // table borrowers
    private $tableBorrower = "tblbtr";
    public $borrowers_ID;
    public $bookID;
    public $title;
    public $studid;
    public $studname;
    public $staff_id;
    public $staffname;
    public $studentNOcopies;
    public $releaseDate;
    public $dueDate;

    // table return
    private $tableReturn = "tblclearedrecords";

     // table reports
     private $tableReports = "tblreports";
   

    // Db dbection
    public function __construct($db){
    $this->db = $db;
    }
              // get all data from student table
              public function getStudent(){
                $sql = "SELECT * FROM " . $this->tableStudent . "";
                $this->result = $this->db->query($sql);
                return $this->result;
                }

              // get all data from book table
              public function getBooks(){
               $sql = "SELECT * FROM " . $this->tableBook . "";
               $this->result = $this->db->query($sql);
               return $this->result;
                }

                // get all data from book user
              public function getUsers(){
                $sql = "SELECT * FROM " . $this->tableUser . "";
                $this->result = $this->db->query($sql);
                return $this->result;
                 }

              // get all data from table borrower
              public function getBorrower(){
                $sql = "SELECT * FROM " . $this->tableBorrower . "";
                $this->result = $this->db->query($sql);
                return $this->result;
                 }

               // get all data from table borrower
               public function getReturn(){
                $sql = "SELECT * FROM " . $this->tableReturn . "";
                $this->result = $this->db->query($sql);
                return $this->result;
                 }

                 // get all data from table borrower
               public function getReports(){
                $sql = "SELECT * FROM " . $this->tableReports . "";
                $this->result = $this->db->query($sql);
                return $this->result;
                 }
  
    
              // inserting data into the database table student
              public function createStudent(){
                // sanitize
                $this->stfname=htmlspecialchars(strip_tags($this->stfname));
                $this->stlname=htmlspecialchars(strip_tags($this->stlname));
                $this->stcourse=htmlspecialchars(strip_tags($this->stcourse));
                $this->styear=htmlspecialchars(strip_tags($this->styear));
                $this->stcontact=htmlspecialchars(strip_tags($this->stcontact));
                $this->stage=htmlspecialchars(strip_tags($this->stage));
                $this->stbirthdate=htmlspecialchars(strip_tags($this->stbirthdate));
                $this->stgender=htmlspecialchars(strip_tags($this->stgender));

                $query = "INSERT INTO ". $this->tableStudent." SET stfname = '".$this->stfname."',
                stlname = '".$this->stlname."',
                stcourse = '".$this->stcourse."',styear = '".$this->styear."'
                ,stcontact = '".$this->stcontact."',stage = '".$this->stage."',stbirthdate = '".$this->stbirthdate."',
                stgender = '".$this->stgender."'";
                $this->db->query($query);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                 // inserting data into the database table borrowers
              public function createBorrower(){
                // sanitize
                $this->bookID=htmlspecialchars(strip_tags($this->bookID));
                $this->title=htmlspecialchars(strip_tags($this->title));
                $this->studid=htmlspecialchars(strip_tags($this->studid));
                $this->studname=htmlspecialchars(strip_tags($this->studname));
                $this->staff_id=htmlspecialchars(strip_tags($this->staff_id));
                $this->staffname=htmlspecialchars(strip_tags($this->staffname));
                $this->studentNOcopies=htmlspecialchars(strip_tags($this->studentNOcopies));
                $this->releaseDate=htmlspecialchars(strip_tags($this->releaseDate));
                $this->dueDate=htmlspecialchars(strip_tags($this->dueDate));

                $query = "INSERT INTO ". $this->tableBorrower." SET book_ID = '".$this->bookID."',
                bktitle = '".$this->title."',
                stud_id = '".$this->studid."',studname = '".$this->studname."'
                ,staff_id = '".$this->staff_id."',staffname = '".$this->staffname."',studentNOcopies = '".$this->studentNOcopies."',
                releaseDate = '".$this->releaseDate."',dueDate = '".$this->dueDate."'";
                $this->db->query($query);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                // inserting data into the database table book
              public function createBook(){
                // sanitize
                $this->bktitle=htmlspecialchars(strip_tags($this->bktitle));
                $this->bkedition=htmlspecialchars(strip_tags($this->bkedition));
                $this->bkauthor=htmlspecialchars(strip_tags($this->bkauthor));
                $this->bkpublisher=htmlspecialchars(strip_tags($this->bkpublisher));
                $this->bkcopies=htmlspecialchars(strip_tags($this->bkcopies));
                $this->bksource=htmlspecialchars(strip_tags($this->bksource));
                $this->bkcost=htmlspecialchars(strip_tags($this->bkcost));
                $this->bkremarks=htmlspecialchars(strip_tags($this->bkremarks));

                $query = "INSERT INTO ". $this->tableBook ." SET bktitle = '".$this->bktitle."',
                bkedition = '".$this->bkedition."',
                bkauthor = '".$this->bkauthor."',bkpublisher = '".$this->bkpublisher."'
                ,bkcopies = '".$this->bkcopies."',bksource = '".$this->bksource."',bkcost = '".$this->bkcost."',
                bkremarks = '".$this->bkremarks."'";
                $this->db->query($query);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                 // inserting data into the database table user
              public function createUser(){
                // sanitize
                $this->stffname=htmlspecialchars(strip_tags($this->stffname));
                $this->stflname=htmlspecialchars(strip_tags($this->stflname));
                $this->stfcontactnumber=htmlspecialchars(strip_tags($this->stfcontactnumber));
                $this->stfaddress=htmlspecialchars(strip_tags($this->stfaddress));
                $this->stfemail=htmlspecialchars(strip_tags($this->stfemail));
                $this->stfpassword=htmlspecialchars(strip_tags($this->stfpassword));
                $this->stftype=htmlspecialchars(strip_tags($this->stftype));
              

                $query = "INSERT INTO ". $this->tableUser ." SET stffname = '".$this->stffname."',
                stflname = '".$this->stflname."',
                stfcontactnumber = '".$this->stfcontactnumber."',stfaddress = '".$this->stfaddress."'
                ,stfemail = '".$this->stfemail."',stfpassword = '".$this->stfpassword."',stftype = '".$this->stftype."'";
                $this->db->query($query);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                // this function is to update data into database table student
              public function updateStudent(){
                $this->stfname=htmlspecialchars(strip_tags($this->stfname));
                $this->stlname=htmlspecialchars(strip_tags($this->stlname));
                $this->stcourse=htmlspecialchars(strip_tags($this->stcourse));
                $this->styear=htmlspecialchars(strip_tags($this->styear));
                $this->stcontact=htmlspecialchars(strip_tags($this->stcontact));
                $this->stage=htmlspecialchars(strip_tags($this->stage));
                $this->stbirthdate=htmlspecialchars(strip_tags($this->stbirthdate));
                $this->stgender=htmlspecialchars(strip_tags($this->stgender));
                
                $sql = "UPDATE ". $this->tableStudent ." SET stfname = '".$this->stfname."',
                stlname = '".$this->stlname."',
                stcourse = '".$this->stcourse."',styear = '".$this->styear."'
                ,stcontact = '".$this->stcontact."',stage = '".$this->stage."',stbirthdate = '".$this->stbirthdate."',
                stgender = '".$this->stgender."'
                WHERE stud_id = ".$this->stud_id;
                
                $this->db->query($sql);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                 // this function is to update data into database table book
              public function updateBook(){
                // sanitize
                $this->bktitle=htmlspecialchars(strip_tags($this->bktitle));
                $this->bkedition=htmlspecialchars(strip_tags($this->bkedition));
                $this->bkauthor=htmlspecialchars(strip_tags($this->bkauthor));
                $this->bkpublisher=htmlspecialchars(strip_tags($this->bkpublisher));
                $this->bkcopies=htmlspecialchars(strip_tags($this->bkcopies));
                $this->bksource=htmlspecialchars(strip_tags($this->bksource));
                $this->bkcost=htmlspecialchars(strip_tags($this->bkcost));
                $this->bkremarks=htmlspecialchars(strip_tags($this->bkremarks));

                $sql = "UPDATE ". $this->tableBook ." SET bktitle = '".$this->bktitle."',
                bkedition = '".$this->bkedition."',
                bkauthor = '".$this->bkauthor."',bkpublisher = '".$this->bkpublisher."'
                ,bkcopies = '".$this->bkcopies."',bksource = '".$this->bksource."',bkcost = '".$this->bkcost."',
                bkremarks = '".$this->bkremarks."' WHERE book_ID = ".$this->book_ID;
                
                $this->db->query($sql);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                 // this function is to update data into database table user
              public function updateUser(){
                // sanitize
                $this->stffname=htmlspecialchars(strip_tags($this->stffname));
                $this->stflname=htmlspecialchars(strip_tags($this->stflname));
                $this->stfcontactnumber=htmlspecialchars(strip_tags($this->stfcontactnumber));
                $this->stfaddress=htmlspecialchars(strip_tags($this->stfaddress));
                $this->stfemail=htmlspecialchars(strip_tags($this->stfemail));
                $this->stfpassword=htmlspecialchars(strip_tags($this->stfpassword));
                $this->stftype=htmlspecialchars(strip_tags($this->stftype));
              

                $query = "UPDATE ". $this->tableUser ." SET stffname = '".$this->stffname."',
                stflname = '".$this->stflname."',
                stfcontactnumber = '".$this->stfcontactnumber."',stfaddress = '".$this->stfaddress."'
                ,stfemail = '".$this->stfemail."',stfpassword = '".$this->stfpassword."',stftype = '".$this->stftype."'";
                $this->db->query($query);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }
                // this function is to delete data into database table customer
              function deleteStudent(){
                $sql = "DELETE FROM " . $this->tableStudent . " WHERE stud_id = ".$this->stud_id;
                $this->db->query($sql);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                // this function is to delete data into database table book
              function deleteBook(){
                $sql = "DELETE FROM " . $this->tableBook . " WHERE book_ID = ".$this->book_ID;
                $this->db->query($sql);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }

                // this function is to delete data into database table user
              function deleteUser(){
                $sql = "DELETE FROM " . $this->tableUser . " WHERE staff_ID = ".$this->staff_ID;
                $this->db->query($sql);
                if($this->db->affected_rows > 0){
                return true;
                }
                return false;
                }
                // this function is to display single student from database table name student
              public function searchStudent(){
                $sql = "SELECT * FROM
                 ". $this->tableStudent ." WHERE stud_id = ".$this->stud_id;
                 $record = $this->db->query($sql);
                 $row=$record->fetch_assoc();
                 $this->stfname = $row['stfname'];
                 $this->stlname = $row['stlname'];
                 $this->stcourse = $row['stcourse'];
                 $this->styear = $row['styear'];
                 $this->stcontact = $row['stcontact'];
                 $this->stage = $row['stage'];
                 $this->stbirthdate = $row['stbirthdate'];
                 $this->stgender = $row['stgender'];
                 
                }

                // this function is to display single student from database table name book
              public function searchBook(){
                $sql = "SELECT * FROM
                 ". $this->tableBook ." WHERE book_ID = ".$this->book_ID;
                 $record = $this->db->query($sql);
                 $row=$record->fetch_assoc();
                 $this->bktitle = $row['bktitle'];
                 $this->bkedition = $row['bkedition'];
                 $this->bkauthor = $row['bkauthor'];
                 $this->bkpublisher = $row['bkpublisher'];
                 $this->bkcopies = $row['bkcopies'];
                 $this->bksource = $row['bksource'];
                 $this->bkcost = $row['bkcost'];
                 $this->bkremarks = $row['bkremarks'];
                 
                }

              // this function is to display single student from database table name user
              public function searchUser(){
                $sql = "SELECT * FROM
                 ". $this->tableUser ." WHERE staff_ID = ".$this->staff_ID;
                 $record = $this->db->query($sql);
                 $row=$record->fetch_assoc();
                 $this->stffname = $row['stffname'];
                 $this->stflname = $row['stflname'];
                 $this->stfcontactnumber = $row['stfcontactnumber'];
                 $this->stfaddress = $row['stfaddress'];
                 $this->stfemail = $row['stfemail'];
                 $this->stfpasword = $row['stfpassword'];
                 $this->stftype = $row['stftype'];
                
                 
                }
                
}
?>