<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
include_once '../database.php';
include_once '../queries.php';
$database = new Database();

$db = $database->getConnection();
$items = new Library($db);
$records = $items->getStudent();
$itemCount = $records->num_rows;
echo json_encode($itemCount);
if($itemCount > 0){
$studentArray = array();
$studentArray["body"] = array();
$studentArray["itemCount"] = $itemCount;
while ($row = $records->fetch_assoc())
{
array_push($studentArray["body"], $row);
}
echo json_encode($studentArray);
}
else{
http_response_code(404);
echo json_encode(
array("message" => "No record found.")
);
}
?>