<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include '../database.php';
include '../queries.php';
$database = new Database();
$db = $database->getConnection();
$item = new Library($db);
$item->stud_id = isset($_GET['stud_id']) ? $_GET['stud_id'] : die();
$item->searchStudent();
if($item->stfname != null){

// create array
$array = array(
"stud_id" => $item->stud_id,
"stfname" => $item->stfname,
"stlname" => $item->stlname,
"stcourse" => $item->stcourse,
"styear" => $item->styear,
"stcontact" => $item->stcontact,
"stage" => $item->stage,
"stbirthdate" => $item->stbirthdate,
"stgender" => $item->stgender
);

http_response_code(200);
echo json_encode($array);
}
else{
http_response_code(404);
echo json_encode("Student not found.");
}
?>