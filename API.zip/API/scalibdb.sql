-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2021 at 05:27 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scalibdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbook`
--

CREATE TABLE `tblbook` (
  `book_ID` int(11) NOT NULL,
  `bktitle` varchar(30) NOT NULL,
  `bkedition` varchar(30) NOT NULL,
  `bkauthor` varchar(30) NOT NULL,
  `bkpublisher` varchar(30) NOT NULL,
  `bkcopies` int(11) NOT NULL,
  `bksource` varchar(30) NOT NULL,
  `bkcost` int(11) NOT NULL,
  `bkremarks` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbook`
--

INSERT INTO `tblbook` (`book_ID`, `bktitle`, `bkedition`, `bkauthor`, `bkpublisher`, `bkcopies`, `bksource`, `bkcost`, `bkremarks`) VALUES
(1, 'C Language', '1', 'Rodofo Javier', '2', 100, 'Library of CHMSC', 100, 'Student'),
(5, 'Pipoi', '3', 'pipz', 'pppp', 0, '0202', 9999, 'wowowow'),
(6, 'DJ_TRANCE', 'HiphopYowww', 'melvz', 'celso', 1, 'utok', 999, 'awesome'),
(7, 'The great pretender', '1', 'Abraham Lincoln', '2', 100, 'Library of australia', 1000, 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `tblbtr`
--

CREATE TABLE `tblbtr` (
  `borrowers_ID` int(11) NOT NULL,
  `book_ID` int(11) NOT NULL,
  `bktitle` varchar(30) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `studname` varchar(30) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `staffname` varchar(30) NOT NULL,
  `studentNOcopies` int(11) NOT NULL,
  `releaseDate` varchar(30) NOT NULL,
  `dueDate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbtr`
--

INSERT INTO `tblbtr` (`borrowers_ID`, `book_ID`, `bktitle`, `stud_id`, `studname`, `staff_id`, `staffname`, `studentNOcopies`, `releaseDate`, `dueDate`) VALUES
(1, 3, 'Tanduay', 2, 'Anthony Degillo', 0, '', 1, '1/16/2017', '1/16/2017'),
(2, 1, 'Hubog', 2, 'Anthony Degillo', 0, '', 1, '1/21/2017', '1/21/2017'),
(3, 5, 'Pipoi', 1, 'Joen Degillo', 3, 'Admin: Joen  Degillo', 0, '2/2/2017', '2/2/2017'),
(4, 0, '', 0, 'Glenn', 1, 'Glenn', 1, '24/06/2021', ''),
(5, 0, '', 0, 'Glenn', 1, 'Glenn', 1, '24/06/2021', '28/06/2021'),
(6, 0, '', 0, 'Glenn', 1, 'Glenn', 1, '24/06/2021', '28/06/2021'),
(7, 0, '', 0, 'Glenn', 1, 'Glenn', 1, '24/06/2021', '28/06/2021'),
(8, 0, '', 0, 'Glenn', 1, 'Glenn', 1, '24/06/2021', '28/06/2021'),
(9, 6, 'The great pretender', 2, 'Glenn', 1, 'Glenn', 1, '24/06/2021', '28/06/2021');

-- --------------------------------------------------------

--
-- Table structure for table `tblclearedrecords`
--

CREATE TABLE `tblclearedrecords` (
  `clearID` int(11) NOT NULL,
  `browID` int(11) NOT NULL,
  `bookID` int(11) NOT NULL,
  `bookTitle` varchar(30) NOT NULL,
  `studID` int(11) NOT NULL,
  `studName` varchar(30) NOT NULL,
  `staffID` int(11) NOT NULL,
  `staffName` varchar(30) NOT NULL,
  `studentcopies` int(11) NOT NULL,
  `releasedates` varchar(30) NOT NULL,
  `duedate` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblclearedrecords`
--

INSERT INTO `tblclearedrecords` (`clearID`, `browID`, `bookID`, `bookTitle`, `studID`, `studName`, `staffID`, `staffName`, `studentcopies`, `releasedates`, `duedate`) VALUES
(10, 8, 1, 'Hubog', 4, 'Carlo Tinasas', 3, 'Admin: Joen  Degillo', 1, '10/9/2016', '10/10/2016'),
(11, 1, 6, 'DJ_TRANCE', 2, 'Anthony Degillo', 3, 'Admin: Joen  Degillo', 1, '10/9/2016', '10/10/2016'),
(12, 1, 6, 'DJ_TRANCE', 2, 'Anthony Degillo', 3, 'Admin: Joen  Degillo', 1, '10/9/2016', '10/10/2016'),
(13, 2, 3, 'Tanduay', 2, 'Anthony Degillo', 3, 'Admin: Joen  Degillo', 1, '10/9/2016', '10/10/2016');

-- --------------------------------------------------------

--
-- Table structure for table `tblreports`
--

CREATE TABLE `tblreports` (
  `rptID` int(11) NOT NULL,
  `rptTransaction_ID` int(11) NOT NULL,
  `rptstaffassigned` varchar(30) NOT NULL,
  `rptbkid` int(11) NOT NULL,
  `rptbktitle` varchar(30) NOT NULL,
  `rptrtnbkcopiesreturn` int(11) NOT NULL,
  `rptrtrndate` varchar(30) NOT NULL,
  `rptremarks` varchar(30) NOT NULL,
  `rptnumberofdays` int(11) NOT NULL,
  `rptpenalty` int(11) NOT NULL,
  `rptrecieve` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblreports`
--

INSERT INTO `tblreports` (`rptID`, `rptTransaction_ID`, `rptstaffassigned`, `rptbkid`, `rptbktitle`, `rptrtnbkcopiesreturn`, `rptrtrndate`, `rptremarks`, `rptnumberofdays`, `rptpenalty`, `rptrecieve`) VALUES
(8, 8, 'Admin: Joen  Degillo', 8, 'Hubog', 1, '10/9/2016', 'Late', 5, 100, 'Admin: Joen  Degillo'),
(9, 1, 'Admin: Joen  Degillo', 1, 'DJ_TRANCE', 1, '10/9/2016', 'Good Condition', 0, 0, 'Admin: Joen  Degillo'),
(10, 0, '', 0, '', 1, '10/9/2016', 'Late', 3, 60, 'Admin: Joen  Degillo'),
(11, 2, 'Admin: Joen  Degillo', 2, 'Tanduay', 1, '10/9/2016', 'Late', 3, 60, 'Admin: Joen  Degillo');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudent`
--

CREATE TABLE `tblstudent` (
  `stud_id` int(11) NOT NULL,
  `stfname` varchar(30) NOT NULL,
  `stlname` varchar(30) NOT NULL,
  `stcourse` varchar(30) NOT NULL,
  `styear` varchar(11) NOT NULL,
  `stcontact` varchar(30) NOT NULL,
  `stage` int(3) NOT NULL,
  `stbirthdate` varchar(30) NOT NULL,
  `stgender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstudent`
--

INSERT INTO `tblstudent` (`stud_id`, `stfname`, `stlname`, `stcourse`, `styear`, `stcontact`, `stage`, `stbirthdate`, `stgender`) VALUES
(1, 'Joen', 'Degillo', 'BSIT', '3', '0909090009', 22, 'Monday, January 10, 1994', 'Male'),
(2, 'Anthony', 'Degillo', 'BSIT', '2', '7777777', 20, 'Wednesday, January 10, 1996', 'Male'),
(3, 'pepoi', 'pipz', 'BSIT', '2', '88888888', 19, 'Friday, January 10, 1997', 'Male'),
(4, 'Carlo', 'Tinasas', 'BSIT', '3', '099999999', 20, 'Thursday, 31 October 1996', 'Male'),
(6, 'Glenn', 'Azuelo', 'BSIT', '2ND', '09161455115', 24, 'FEB 15 1996', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `staff_ID` int(11) NOT NULL,
  `stffname` varchar(30) NOT NULL,
  `stflname` varchar(30) NOT NULL,
  `stfcontactnumber` int(11) NOT NULL,
  `stfaddress` varchar(30) NOT NULL,
  `stfemail` varchar(30) NOT NULL,
  `stfpassword` varchar(15) NOT NULL,
  `stftype` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`staff_ID`, `stffname`, `stflname`, `stfcontactnumber`, `stfaddress`, `stfemail`, `stfpassword`, `stftype`) VALUES
(3, 'Joen', 'Degillo', 2147483647, 'Cauayan Negros Island', 'joen', '123', 'Admin'),
(4, 'Neo', 'Degillo', 2147483647, 'Poblacion Cauayan Negros Islan', 'neoj', '123', 'Librarian'),
(6, 'Glenn', 'Azuelo', 2147483647, 'Cauayan', 'glennazuelo1@gmail.com', 'glenn', 'librarian'),
(7, 'Glenn', 'Azuelo', 2147483647, 'Cauayan', 'glennazuelo1@gmail.com', 'glennazuelo', 'librarian');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblbook`
--
ALTER TABLE `tblbook`
  ADD PRIMARY KEY (`book_ID`);

--
-- Indexes for table `tblbtr`
--
ALTER TABLE `tblbtr`
  ADD PRIMARY KEY (`borrowers_ID`);

--
-- Indexes for table `tblclearedrecords`
--
ALTER TABLE `tblclearedrecords`
  ADD PRIMARY KEY (`clearID`);

--
-- Indexes for table `tblreports`
--
ALTER TABLE `tblreports`
  ADD PRIMARY KEY (`rptID`);

--
-- Indexes for table `tblstudent`
--
ALTER TABLE `tblstudent`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`staff_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblbook`
--
ALTER TABLE `tblbook`
  MODIFY `book_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblbtr`
--
ALTER TABLE `tblbtr`
  MODIFY `borrowers_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblclearedrecords`
--
ALTER TABLE `tblclearedrecords`
  MODIFY `clearID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblreports`
--
ALTER TABLE `tblreports`
  MODIFY `rptID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblstudent`
--
ALTER TABLE `tblstudent`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `staff_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
